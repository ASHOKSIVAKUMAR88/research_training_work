#ifndef INCLUDES_H
	#define INCLUDES_H
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#define MAXSIZE 5
#define big(a,b,c) (a>b?(a>c?a:c):(b>c?b:c))
int main1(void);
int main2(void);
int main3(void);
int main4(void);

#endif
